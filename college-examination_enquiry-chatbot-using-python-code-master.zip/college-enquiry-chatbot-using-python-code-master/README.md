# college-enquiry-chatbot-using-python-code
There have 5 .txt file
Before using this chatbot, you must read all .txt file because the chatbot answered you those types of questions are inputed.
or you can added your own question, all the questions are always write with pair 1st line is question and 2nd line is answere.
example:
How are you? //this is question
fine.    //this is answere

 Thanks a lot for read this...
